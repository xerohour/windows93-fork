FILE "Five Night at Freddy's 2 (v1.0.2).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
